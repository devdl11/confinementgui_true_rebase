import './App.css';
import './Menu.css';
import React from 'react'

class Loading extends React.Component{
    render() {
        return (
            <div className="Login">
                <div className="titre">Chargement en cours...</div>
            </div>
            );
    }
}

export default Loading